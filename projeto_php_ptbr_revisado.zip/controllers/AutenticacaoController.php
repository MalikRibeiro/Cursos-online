<?php
namespace app\controller;
class ControladorAutenticacao {
    public function login() { include __DIR__ . '/../view/autenticacao/login.php'; }
    public function cadastrar() { include __DIR__ . '/../view/autenticacao/cadastrar.php'; }
    public function recuperar() { include __DIR__ . '/../view/autenticacao/recuperar.php'; }
    // Métodos para processar formulários omitidos
}
