<?php
namespace app\controller;
use app\model\Curso;
class ControladorCurso {
    public function listar() {
        $cursos = Curso::todos();
        include __DIR__ . '/../view/cursos/listar.php';
    }
    public function adicionar() { include __DIR__ . '/../view/cursos/adicionar.php'; }
    public function editar(int $id) { $curso = Curso::buscarPorId($id); include __DIR__ . '/../view/cursos/editar.php'; }
    public function visualizar(int $id) { $curso = Curso::buscarPorId($id); include __DIR__ . '/../view/cursos/visualizar.php'; }
    // Métodos CRUD omitidos
}
