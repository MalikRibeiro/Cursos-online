<?php
namespace app\controller;
class ControladorHome {
    public function iniciar() { include __DIR__ . '/../view/home.php'; }
    public function sobre() { include __DIR__ . '/../view/sobre.php'; }
    public function contato() { include __DIR__ . '/../view/contato.php'; }
}
