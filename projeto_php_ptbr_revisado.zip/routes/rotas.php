<?php
use app\controller\ControladorHome;
use app\controller\ControladorAutenticacao;
use app\controller\ControladorCurso;

$request = $_SERVER['REQUEST_URI'];
if (strpos($request, '/cursos') === 0) {
    $controlador = new ControladorCurso();
    if ($request === '/cursos/adicionar') $controlador->adicionar();
    elseif ($request === '/cursos/editar' && isset($_GET['id'])) $controlador->editar((int)\$_GET['id']);
    elseif ($request === '/cursos/visualizar' && isset($_GET['id'])) $controlador->visualizar((int)\$_GET['id']);
    else $controlador->listar();
} elseif (strpos($request, '/autenticacao') === 0) {
    $controlador = new ControladorAutenticacao();
    if ($request === '/autenticacao/cadastrar') $controlador->cadastrar();
    elseif ($request === '/autenticacao/recuperar') $controlador->recuperar();
    else $controlador->login();
} else {
    $controlador = new ControladorHome();
    if ($request === '/sobre') $controlador->sobre();
    elseif ($request === '/contato') $controlador->contato();
    else $controlador->iniciar();
}
