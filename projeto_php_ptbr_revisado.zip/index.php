<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../app/init.php';
require_once __DIR__ . '/../routes/rotas.php';
